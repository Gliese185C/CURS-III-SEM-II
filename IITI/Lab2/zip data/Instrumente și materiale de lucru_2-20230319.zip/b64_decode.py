import base64

inputs = raw_input ("Phrase to decode:")
print base64.b64decode(inputs)


